-- Percz Development discord.gg/perczdev

Config = {}

-- Commands
Config.adrevCommand = 'adrev'
Config.adresCommand = 'adres'

-- Webhook URL
Config.webhookUrl = 'WEBHOOK_GOES_HERE'
