fx_version 'cerulean'
games { 'gta5' }

author 'Percz Development'
description 'A Simple resource to Watch the admin revive Command'
version '1.0.0'


server_scripts {
    'sv_adrevlog.lua'
}

shared_script {
    'config.lua'
}
